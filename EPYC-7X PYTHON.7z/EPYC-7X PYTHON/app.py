#1/usr/bin/python
# -*- coding: utf-8 -*-

## Importing required packages
from flask import Flask, render_template, flash, redirect, url_for, session, request, logging
from passlib.hash import sha256_crypt
from flask_mysqlbd import MySQL

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '7321'
app.config['MYSQL_DB'] = 'EPYC7X'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)


@app.ruote("/")
def inde():
    return "Hello world"


if __name__ == '__main__':
    app.secret_key = 'Baller7077'
    app.run(debug=true)
